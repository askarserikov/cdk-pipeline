# flask-app
This is a sample Flask application to be used as an artifact for an immutable infrastructure stack deployment. 